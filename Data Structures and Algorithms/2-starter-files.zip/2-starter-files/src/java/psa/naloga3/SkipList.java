package psa.naloga3;
import java.util.Random; 
public class SkipList {

	private NodeSkipList head; 
	NodeSkipList rightSentinel;
	int height;
	Integer inf = Integer.MAX_VALUE;
	Integer negInf = Integer.MIN_VALUE;
	/*
	 * Tvoritelj sprejme kot parameter stevilo elementov, ki jih je sposoben obdelati
	 */
	public SkipList(long maxNodes) {
		this.height = (int) Math.log(maxNodes);
		this.head = new NodeSkipList(negInf, this.height);
		this.rightSentinel = new NodeSkipList(inf, this.height);
		for(int i=0;i<=height;i++){
			this.head.linked[i] = rightSentinel;
		}
	}

	/*
	 * Metoda sprejme stevilo in ga vstavi v preskocni seznam. Ce element ze
	 * obstaja v podatkovni strukturi, vrne false. Metoda vrne true, ce je bil
	 * element uspesno vstavljen in false sicer.
	 */
	public boolean insert(int searchKey) {
		int levels = coinToss();
		//System.out.println("levels of "+searchKey+": " + levels);
		NodeSkipList newNode = new NodeSkipList(searchKey, levels);
		/*for(int i=0;i<=levels;i++){
			System.out.print(head.linked[i].key+" ");
		}
		System.out.println();*/
		if(head.linked[0].key==inf){
			//System.out.println(head.key);
			for(int i = 0; i <= levels; i++){
				head.linked[i] = newNode;
				newNode.linked[i] = rightSentinel;
				//System.out.print(head.linked[i].key+" ");
			}
			//System.out.println();
			//System.out.println("head set");
			return true;
		}
		if(searchKey==head.key){
			return false;
		}
		NodeSkipList current = head;
		int i = height;
		//System.out.println("height: "+i);
		//System.out.println("current is: "+current.key);
		NodeSkipList[] before = new NodeSkipList[levels+1];
		while(i>=0){
			//System.out.println("next is: "+current.linked[i].key);
			if(searchKey==current.linked[i].key){
				return false;
			}
			else if(searchKey>current.linked[i].key){
				current = current.linked[i];
			}
			else{
				if(i<=levels){
					before[i]=current;
				}
				i--;
			}
		}
		for(int j=levels;j>=0;j--){
			newNode.linked[j]=before[j].linked[j];
			before[j].linked[j]=newNode;
			//System.out.print(newNode.linked[j].key+ " ");
		}
		//System.out.println();
		return true;
	}


	public int coinToss(){
		Random r = new Random();
		int toss = r.nextInt(2);
		int count = 0;
		while(toss != 0){
			toss = r.nextInt(2);
			count++;
			if(count==this.height){
				return count;
			}
		}
		return count;
	}
	/*
	 * Metoda sprejme stevilo in poisce element v preskocnem seznamu. Metoda
	 * vrne true, ce je bil element uspesno najden v podatkovni strukturi, in
	 * false sicer
	 */
	public boolean search(int searchKey) {
		NodeSkipList current = head;
		int level = height;
		while(level>=0){
			if(current.key==searchKey){
				return true;
			}
			else if(searchKey<current.linked[level].key){
				level --;
			}
			else{
				current = current.linked[level];
			}
		}
		return false;
	}

	/*
	 * Metoda sprejme stevilo in izbrise element iz preskocnega seznama. Metoda
	 * vrne true, ce je bil element uspesno izbrisan iz podatkovne strukture, in
	 * false sicer
	 */
	public boolean delete(int key) {
		NodeSkipList current = head;
		int level = height;
		while(level>=0){
			if(current.key==key){
				this.update(current, current.linked.length-1);
				return true;
				}
			else if(key<current.linked[level].key){
				level --;
			}
			else{
				current = current.linked[level];
			}
		}
		return false;
		
	}

public void update(NodeSkipList old, int l){
	NodeSkipList current = head;
	while(current.key < old.key){
		for(int i=0;i<=Math.min(current.linked.length-1,l);i++){
			if(current.linked[i]==old){
				current.linked[i]=old.linked[i];
			}
		}
		current=current.linked[0];
	}
}

	public void printEverything() {
        NodeSkipList ptr = this.head;
        System.out.println( "Head Node " );
        ptr.printForward();
        ptr = ptr.linked[0];
        while (ptr != null) {
            System.out.println( "Node (" + ptr.key  + ")" );
            ptr.printForward();
            ptr = ptr.linked[0];
        }
    }
}
