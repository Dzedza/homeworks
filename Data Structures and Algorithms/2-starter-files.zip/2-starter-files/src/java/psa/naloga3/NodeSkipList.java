package psa.naloga3;

public class NodeSkipList {
    int key;
    NodeSkipList[] linked;

    public NodeSkipList(int key, int size){
        this.key = key;
        this.linked = new NodeSkipList[size+1];
    }
    public void printForward( ) {
        for (int i = this.linked.length-1; i >= 0; i--) {
            if (this.linked[i] == null)
                System.out.println( "level : " + i + " ----> null" );
            else
                System.out.println( "level : " + i + " ----> (" + this.linked[i].key+ ")");
        }
    }
}
