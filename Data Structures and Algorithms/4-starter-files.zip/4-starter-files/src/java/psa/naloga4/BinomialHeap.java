package psa.naloga4;

import java.util.Vector;

public class BinomialHeap {
	BinomialNode[] data;
	int size;
	Integer inf = Integer.MAX_VALUE;
	
	BinomialHeap(){
		data = new BinomialNode[1];
		size = 1;
	}
	
	public boolean insert(int key) {
		BinomialNode newNode = new BinomialNode(key);
		int place = 0;
		while(data[place]!=null){
			newNode = merge(newNode, data[place]);
			if(place==size-1){
				resizeArray();
			}
			data[place] = null;
			place++;
		}
		data[place] = newNode;
		return true;

	}
	
	public int getMin() {
		int m = inf;
		for(int i=0;i<size;i++){
			if(data[i]!=null){
				int check = data[i].getKey();
				if(check<m){
					m = check;
				}
			}
		}
		return m;
	}

	public boolean delMin() {
		int place = getMinIndex();
		if(data[place]==null){
			return false;
		}
		int len = data[place].childs.size();
		BinomialNode[] children = new BinomialNode[len];
		for(int i=0;i<len;i++){
			children[i] = data[place].childs.get(len-1-i);	
		}
		data[place] = null;
		data = mergeHeaps(data,children);
		return true;
	}

	public BinomialNode[] mergeHeaps(BinomialNode[] h1, BinomialNode[] h2){
		BinomialNode[] newData = new BinomialNode[h1.length];
		int i = 0;
		while(i<h2.length){
			if(h1[i]==null){
				
				if(newData[i]!=null&&h2[i]!=null){
					newData[i+1] = merge(newData[i],h2[i]);
					newData[i] = null;
				}
				else{
					newData[i]=h2[i];
				}
			}
			else if(h2[i]==null){
				if(newData[i]!=null&&h1[i]!=null){
					newData[i+1] = merge(newData[i],h1[i]);
					newData[i] = null;
				}
				else{
					newData[i]=h1[i];
				}
			}
			else{
				newData[i+1] = merge(h1[i],h2[i]);
			}
			i++;
		}
		if(h1.length>h2.length+1){
			for(int j=i+1;j<h1.length;j++){
				newData[j]=h1[j];
			}
		}
		return newData;
	}


	public int getMinIndex() {
		int m = inf;
		int place = 0;
		for(int i=0;i<data.length;i++){
			if(data[i]!=null){
				int check = data[i].getKey();
				if(check<m){
					m = check;
					place = i;
				}
			}
		}
		return place;
	}
	
	private void resizeArray() {
		BinomialNode[] newData = new BinomialNode[size*2];
		for(int i=0;i<size;i++){
			newData[i] = data[i];
		}
		data = newData;
		size = 2*size;
	}
	
	private BinomialNode merge(BinomialNode t1, BinomialNode t2) {
		if(t1==null){
			return t2;
		}
		if(t2==null){
			return t1;
		}
		BinomialNode makesNew;
		BinomialNode newChild;
		if(t1.key<t2.key){
			makesNew = t1;
			newChild = t2;
		}
		else{
			makesNew = t2;
			newChild = t1;
		}
		BinomialNode newRoot = new BinomialNode(makesNew.key);
		newRoot.addChild(newChild);
		Vector<BinomialNode> l = makesNew.getChilds(); 
		for(int i=0;i<l.size();i++){
			newRoot.addChild(l.get(i));
		}
		return newRoot;
	}
}

