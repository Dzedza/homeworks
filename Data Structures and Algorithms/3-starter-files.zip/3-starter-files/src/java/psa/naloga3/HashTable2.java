package psa.naloga3;

import java.util.Arrays;

/*
 * Razred mora imeplementirati podatkovno strukturo Razprsilne tabele.
 * Za funkcijo uporabite: h(x) = x * 53 mod 100
 * V primeru kolizij uporabite LINEARNO NASLAVLJANJE.
 */
public class HashTable2 {

	int[] data;
	int[] data2;

	public HashTable2(){
		this.data = new int[100];
		this.data2 = new int[100];
	}

	/*
	 * Metoda sprejme število in ga vstavi v tabelo. Metoda vrne true, ce je
	 * bilo ustavljanje uspešno in false sicer
	 */
	public boolean insert(int key) {
		boolean res = false;
		int i = 0;
		for(int j=0;j<100;j++){
			int place = hashFcn(key, i);
			if(data[place]==key){
				return false;
			}
			if(data[place]==0){
				data[place] = key;
				return true;
			}
			i++;
		}
		return false;
		
	}

	/*
	 * Metoda sprejme število in ga poišče v tabeli. Metoda vrne true, ce je
	 * bilo ustavljanje uspešno in false sicer
	 */
	public boolean search(int key) {
		int i = 0;
		for(int j=0;j<100;j++){
			int place = hashFcn(key, i);
			if(data[place]!='\0'&&data[place]==key){
				return true;
			}
			i++;
		}
		return false;
	}

	/*
	 * Metoda sprejme število in ga izbriše iz tabele. Metoda vrne true, ce je
	 * bilo ustavljanje uspešno in false sicer
	 */
	public boolean delete(int key) {
		int i=0;
		for(int j=0;j<100;j++){
			int place = hashFcn(key, i);
			if(data[place]==key){
				data[place] = '\0';
				helper();
				return true;
			}
			i++;
		}
		return false;
	}

	public void helper(){
		data2 = data;
		data = new int[100];
		for(int i=0;i<100;i++){
			if(data2[i]!=0){
				insert(data2[i]);
			}
		}
		data2 = new int[100];
	}

	public void printFcn(){
		for(int i=0;i<100;i++){
			System.out.print(data[i]+" ");
		}
		System.out.println();
	}

	public int hashFcn(int key, int i){
		return Math.abs(key*53+i) % 100;
	}
}
