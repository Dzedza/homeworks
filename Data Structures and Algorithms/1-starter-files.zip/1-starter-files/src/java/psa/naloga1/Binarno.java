package psa.naloga1;

public class Binarno {
	private NodeBinarno root;

	/*
	 * Metoda sprejme celo stevilo in ga vstavi v drevo. Ce element ze obstaja v drevesu, vrne false
	 * Metoda vrne true, ce je bil element uspesno vstavljen in false sicer.
	 */
	public boolean insert(int element) {
		NodeBinarno newNode = new NodeBinarno(element);
		if(root == null){
			root = newNode;
			return true;
		}
		NodeBinarno current = root;
		NodeBinarno parent;
		int check;
		while(true){
			check = current.compare(newNode);
			parent = current;
			if (check == 0){
				return false;
			}
			else if (check < 0){
				current = current.left;
				if(current == null){
					parent.left = newNode;
					newNode.parent = parent;
					return true;
				}
			}
			else{
				current = current.right;
				if(current == null){
					parent.right = newNode;
					newNode.parent = parent;
					return true;
				}
			}
		}
	}

	/*
	 * Metoda sprejme celo stevilo in izbrise element iz drevesa. 
	 * Metoda vrne true, ce je bil element uspesno izbrisan iz drevesa, in false sicer
	 */

	public void transplant(NodeBinarno old, NodeBinarno newN) {
		if(old.parent == null){
			this.root = newN;
		}
		else if(old == old.parent.left){
			old.parent.left = newN;
		}
		else{
			old.parent.right = newN;
		}
		if(newN != null){
			newN.parent = old.parent;
		}
		
	}

	public NodeBinarno findMin(NodeBinarno toCheck){
		if (toCheck.left == null){
			return toCheck;
		}
		else{
			return findMin(toCheck.left);
		}
	}

	public boolean delete(int element){
		NodeBinarno target = new NodeBinarno(element);
		NodeBinarno current = root;
		int check;
		while(current != null){
			check = current.compare(target);
			if(check == 0){
				if(current.left == null){
					transplant(current, current.right);
				}
				else if(current.right == null){
					transplant(current, current.left);
				}
				else{
					NodeBinarno min = findMin(current.right);
					if(min.parent != current){
						transplant(min, min.right);
						min.right = current.right;
						min.right.parent = min;
					}
					transplant(current, min);
					min.left = current.left;
					min.left.parent = min;
				}
				return true;
			}
			else if(check < 0){
				current = current.left;
			}
			else{
				current = current.right;
			}
		}
		return false;
	}

	/*
	 * Metoda sprejme celo stevilo in poisce element v drevesu. 
	 * Metoda vrne true, ce je bil element uspesno najden v drevesu, in false sicer
	 */
	public boolean search(int element) {
		NodeBinarno target = new NodeBinarno(element);
		NodeBinarno current = root;
		int check;
		while(current != null){
			check = current.compare(target);
			if(check == 0){
				return true;
			}
			else if(check < 0){
				current = current.left;
			}
			else{
				current = current.right;
			}
		}
		return false;
	}

	public void printIn(NodeBinarno node){
		if(node != null){
			printIn(node.left);
			System.out.print(node.getKey()+" ");
			printIn(node.right);
		}

	}

	public void printing(){
		printIn(root);
	}

	public int getCounter() {
		return root != null?root.getCounter():null;
	}
	
	public void resetCounter() {
		if(root!= null)
			root.resetCounter();
	}

}

