package psa.naloga1;

public class NodeBinarno {
	private static int counter;
	private int key;
	public NodeBinarno left;
	public NodeBinarno right;
	public NodeBinarno parent;

	public NodeBinarno(int key){
		this.key = key;
		this.left = null;
		this.right = null;
		this.parent = null;
	}
	
	public int compare(NodeBinarno node) {
		counter++;
		return node.key - this.key;
	}
	
	public int getCounter() {
		return counter;
	}
	
	public void resetCounter() {
		counter=0;
	}

	public int getKey(){
		return this.key;
	}
}
