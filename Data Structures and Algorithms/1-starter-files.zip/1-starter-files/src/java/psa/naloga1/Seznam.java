package psa.naloga1;

public class Seznam {
	private NodeSeznam head;

	/*
	 * Metoda sprejme celo stevilo in ga vstavi v seznam. Ce element ze obstaja v seznamu, vrne false
	 * Metoda vrne true, ce je bil element uspesno vstavljen in false sicer.
	 */
	public boolean insert(int element) {
		NodeSeznam newNode = new NodeSeznam(element);
		if(head == null){
			head = newNode;
			return true;
		}
		NodeSeznam current = head;
		while(current.tail != null){
			if (current.compare(newNode) == 0){
				return false;
			}
			current = current.tail;
		}
		current.tail = newNode;
		return true;
	}

	/*
	 * Metoda sprejme celo stevilo in izbrise element iz seznama. 
	 * Metoda vrne true, ce je bil element uspesno izbrisan iz seznama, in false sicer
	 */
	public boolean delete(int element) {
		NodeSeznam target = new NodeSeznam(element);
		NodeSeznam current = head;
		while(current.tail != null){
			if (current.tail.compare(target) == 0){
				current.tail = current.tail.tail;
				return true;
			}
			current = current.tail;
		}
		return false;
	}

	/*
	 * Metoda sprejme celo stevilo in poisce element v seznamu. 
	 * Metoda vrne true, ce je bil element uspesno najden v seznamu, in false sicer
	 */
	public boolean search(int element) {
		NodeSeznam target = new NodeSeznam(element);
		NodeSeznam current = head;
		while(current != null){
			if (current.compare(target) == 0){
				return true;
			}
			current = current.tail;
		}
		return false;
	}
	
	public int getCounter() {
		return head != null?head.getCounter():null;
	}
	
	public void resetCounter() {
		if(head!= null)
			head.resetCounter();
	}

}
