package psa.naloga2;


public class UnionFind {
	public int[] id;

	public UnionFind(int N) {
		this.id = new int[N];
		for(int i=0;i<N;i++){
			id[i] = i;
		}
	}

	/*
	 * Metoda sprejme index in vrne predstavnika mnozice, katere clan je index.
	 */
	public int find(int i) {
		int j = id[i];
		int k = i;
		while(i!=j){
			i = j;
			j = id[j];
		}
		while(k!=i){
			int tmp = id[k];
			id[k] = i;
			k = tmp;
		}
		return i;
	}

	/*
	 * Metoda sprejme da indexa in naredi unijo
	 */
	public void unite(int p, int q) {
		id[find(q)] = id[find(p)];
	}
	
	/*
	 * Metoda vrne true, ce sta p in q v isti mnozici
	 */
	public boolean isInSameSet(int p, int q) {
		if(find(p)==find(q)){
			return true;
		}
		return false;
	}
}
