package psa.naloga5;

public class Prim {
	int[][] data;
	int n;
	int inf = Integer.MAX_VALUE;

	public Prim(int n) {
		data = new int[n][n];
		this.n = n;
	}

	public Prim(int[][] d) {
		this.data= d;
		this.n = data.length;
	}

	public void addEdge(int i, int j, int d) {
		data[i][j]=d;
		data[j][i]=d;
	}

	public int MSTcost() {
		int[] parents = new int[n];
		int[] values = new int[n];
		Boolean[] used = new  Boolean[n];
		for(int i=0;i<n;i++){
			values[i] = inf;
			used[i] = false;
		}
		values[0]=0;
		parents[0]=0;
		for(int i=0;i<n-1;i++){
			int add = findMin(values, used);
			used[add] = true;
			for(int j=0;j<n;j++){
				if(data[add][j]!=0 && used[j] == false && data[add][j]<values[j]){
					parents[j] = add;
					values[j] = data[add][j];
				}
			}
		}
		int m = 0;
		for(int i=0;i<n;i++){
			m += data[i][parents[i]];
		}
		return m;
	}
		
	public int[] prim(int s) {
		int[] parents = new int[n];
		int[] values = new int[n];
		Boolean[] used = new  Boolean[n];
		for(int i=0;i<n;i++){
			values[i] = inf;
			used[i] = false;
		}
		values[s]=0;
		parents[s]=0;
		for(int i=0;i<n-1;i++){
			int add = findMin(values, used);
			used[add] = true;
			for(int j=0;j<n;j++){
				if(data[add][j]!=0 && used[j] == false && data[add][j]<values[j]){
					parents[j] = add;
					values[j] = data[add][j];
				}
			}
		}
		return parents;
	}
	public int findMin(int[] values, Boolean[] used){
		int min = inf;
		int index = -1;
		for(int i=0;i<n;i++){
			if(used[i]==false && values[i]<min){
				min = values[i];
				index = i;
			}
		}
		return index;
	}

}
